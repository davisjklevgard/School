package edu.cvtc.java;

public class FreeCheckingAccount extends BankAccount{
    //Attributes
    private final double MIN_BALANCE = 100.0;

    //Default
    public FreeCheckingAccount(){
        setBalance(MIN_BALANCE);
    }

    //OverLoad
    public FreeCheckingAccount(double balance){
        if (balance < MIN_BALANCE){
            setBalance(MIN_BALANCE);
        } else {
            setBalance(balance);
        }
    }

    public void withdraw(double amount){
        if (getBalance() >= MIN_BALANCE){
            if ((getBalance() - amount) >= MIN_BALANCE){
                setBalance(getBalance() - amount);
            }
        }
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal += "Free checking balance: " + getBalance() + "\n";


        return retVal;
    }
}
