package edu.cvtc.java;

public class BankAccount {
    //Attributes
    private double balance;
    private final double MIN_BALANCE = 0.0;

    //Default
    public BankAccount(){
        setBalance(0.0);
    }

    public BankAccount(double balance){
        setBalance(balance);
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public void deposit(double amount){

    }

    public void withdraw(double amount){
        if (getBalance() >= MIN_BALANCE){
            if ((getBalance() - amount) >= MIN_BALANCE){
                setBalance(getBalance() - amount);
            }
        }
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal += "Balance: " + getBalance() + "\n";


        return retVal;
    }
}
