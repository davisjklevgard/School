package edu.cvtc.java;

public class SavingsAccount extends BankAccount{
    //Attributes
    private final double MIN_BALANCE = 5.0;

    //Default
    public SavingsAccount(){
        setBalance(MIN_BALANCE);
    }

    //OverLoad
    public SavingsAccount(double balance){
        if (balance < MIN_BALANCE){
            setBalance(MIN_BALANCE);
        } else {
            setBalance(balance);
        }
    }

    public void withdraw(double amount){
        if (getBalance() >= MIN_BALANCE){
            if ((getBalance() - amount) >= MIN_BALANCE){
                setBalance(getBalance() - amount);
            }
        }
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal += "Savings Account balance: " + getBalance() + "\n";


        return retVal;
    }
}
