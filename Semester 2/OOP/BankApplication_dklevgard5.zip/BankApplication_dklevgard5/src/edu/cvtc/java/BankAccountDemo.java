package edu.cvtc.java;

public class BankAccountDemo {

    public static void main(String[] args) {
        BankAccount businessCheckingAccount = new BusinessCheckingAccount(1500.0);
        BankAccount freeCheckingAccount = new FreeCheckingAccount(500.0);
        BankAccount savingsAccount = new SavingsAccount(1000.0);

        //Array
        BankAccount[] bankAccounts = {businessCheckingAccount, freeCheckingAccount, savingsAccount};

        System.out.println("Withdrawing 100");

        for (int i = 0; i < bankAccounts.length; i++){
            System.out.print(bankAccounts[i]);
            bankAccounts[i].withdraw(100);
            System.out.print(bankAccounts[i]);
            System.out.println();
        }

        //Remove 4 more
        System.out.println("Withdrawing 500");

        for (int i = 0; i < bankAccounts.length; i++){
            System.out.print(bankAccounts[i]);
            bankAccounts[i].withdraw(500);
            System.out.print(bankAccounts[i]);
            System.out.println();
        }
    }

}
