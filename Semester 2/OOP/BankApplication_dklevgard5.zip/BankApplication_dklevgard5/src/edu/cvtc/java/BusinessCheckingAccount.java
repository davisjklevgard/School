package edu.cvtc.java;

public class BusinessCheckingAccount extends BankAccount{

    //Attributes
    private final double MIN_BALANCE = 1000.0;

    //Default
    public BusinessCheckingAccount(){
        setBalance(MIN_BALANCE);
    }

    //OverLoad
    public BusinessCheckingAccount(double balance){
        if (balance < MIN_BALANCE){
            setBalance(MIN_BALANCE);
        } else {
            setBalance(balance);
        }
    }

    public void withdraw(double amount){
        if (getBalance() >= MIN_BALANCE){
            if ((getBalance() - amount) >= MIN_BALANCE){
                setBalance(getBalance() - amount);
            }
        }
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal += "Business checking balance: " + getBalance() + "\n";


        return retVal;
    }
}
