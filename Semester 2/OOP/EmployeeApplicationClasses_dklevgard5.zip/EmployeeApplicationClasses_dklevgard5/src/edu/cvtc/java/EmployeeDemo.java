package edu.cvtc.java;

public class EmployeeDemo {


    public static void main(String[] args) {

        Employee employee = new Employee("Sam", "124-F", "10/06/2008");
        ProductionWorker productionWorker = new ProductionWorker("Travis", "342-G", "01/03/2009", 40, 18.50);
        TeamLeader teamLeader = new TeamLeader("Kat", "789-K", "09/14/2017", 40, 22.25, 40.50, 12, 5);
        ShiftSupervisor shiftSupervisor = new ShiftSupervisor("Logan", "564-L", "12/14/2018", 42000.00, 2300.00);



        System.out.println("Employee: " + employee);
        System.out.println("Production Worker: " + productionWorker);
        System.out.println("Team Leader: " + teamLeader);
        System.out.println("Shift Supervisor: " + shiftSupervisor);
    }
}
