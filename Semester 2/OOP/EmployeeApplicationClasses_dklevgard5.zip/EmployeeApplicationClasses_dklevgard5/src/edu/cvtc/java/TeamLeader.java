package edu.cvtc.java;

public class TeamLeader extends ProductionWorker{

    //Attributes
    private double monthlyBonus;
    private double trainingHoursRequired;
    private double trainingHoursAttended;

    //Default
    public TeamLeader(){
        super();
    }

    //Overload
    public TeamLeader(String name, String number, String hireDate, int shift, double payRate,
                      double monthlyBonus, double trainingHoursRequired, double trainingHoursAttended){
        super(name, number, hireDate, shift, payRate);
        setMonthlyBonus(monthlyBonus);
        setTrainingHoursRequired(trainingHoursRequired);
        setTrainingHoursAttended(trainingHoursAttended);
    }

    //Methods

    public double getMonthlyBonus() {
        return monthlyBonus;
    }

    public void setMonthlyBonus(double monthlyBonus) {
        this.monthlyBonus = monthlyBonus;
    }

    public double getTrainingHoursRequired() {
        return trainingHoursRequired;
    }

    public void setTrainingHoursRequired(double trainingHoursRequired) {
        this.trainingHoursRequired = trainingHoursRequired;
    }

    public double getTrainingHoursAttended() {
        return trainingHoursAttended;
    }

    public void setTrainingHoursAttended(double trainingHoursAttended) {
        this.trainingHoursAttended = trainingHoursAttended;
    }

    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal +=   "Monthly Bonus: " + getMonthlyBonus() + "\n";
        retVal += "Training Hours Required: " + getTrainingHoursRequired() + "\n";
        retVal += "Training Hours Attended: " + getTrainingHoursAttended() + "\n";

        return retVal;
    }
}
