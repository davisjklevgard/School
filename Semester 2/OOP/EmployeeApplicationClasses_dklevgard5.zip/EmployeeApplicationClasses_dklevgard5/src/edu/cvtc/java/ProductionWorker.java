package edu.cvtc.java;

public class ProductionWorker extends Employee{

    //Attributes
    private int shift;
    private double payRate;

    //Default
    public ProductionWorker(){
        super();
    }

    //Overload
    public ProductionWorker(String name, String number, String hireDate, int shift, double payRate){
        super(name, number, hireDate);
        setShift(shift);
        setPayRate(payRate);
    }

    //Methods

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    public double getPayRate() {
        return payRate;
    }

    public void setPayRate(double payRate) {
        this.payRate = payRate;
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal +=   "Shift: " + getShift() + "\n";
        retVal += "Pay Rate: " + getPayRate() + "\n";


        return retVal;
    }
}
