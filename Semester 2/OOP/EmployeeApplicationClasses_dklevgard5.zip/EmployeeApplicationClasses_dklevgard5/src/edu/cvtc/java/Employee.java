package edu.cvtc.java;

public class Employee {

    //Attributes
    private String name;
    private String number;
    private String hireDate;

    //Default
    public Employee() {
        setName("");
        setNumber("");
        setHireDate("");
    }

    //Overload
    public Employee(String name, String number, String hireDate){
       setName(name);
       setNumber(number);
       setHireDate(hireDate);
    }

    //Methods

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        if (isValidNumber(number)) {
            this.number = number;
        } else  {
            this.number = "Invalid Employee Number.";
        }
    }

    private boolean isValidNumber(String number){
        //local variables
        boolean isValid = true;
        char[]  chars;
        int index = 0;

        chars = number.toCharArray();

        int i1 = Character.getNumericValue(chars[4]);

        //Check #1: Is it 4 characters
        if (number.length() != 5){
            isValid = false;
       }

        //Check for digits
        while (isValid && index < 2)  {
            if (!Character.isDigit(chars[index])){
                isValid = false;
            }
            index++;
        }

        if (i1 < 10 || i1 > 22){
            isValid = false;
        }

        return isValid;
    }

    public String getHireDate() {
        return hireDate;
    }

    public void setHireDate(String hireDate) {
        this.hireDate = hireDate;
    }

    @Override
    public String toString() {
        String retVal = "";

        retVal = "Name: " + getName() + "\n";
        retVal +=   "Number: " + getNumber() + "\n";
        retVal += "Hire Date: " + getHireDate() + "\n";


        return retVal;
    }
}
