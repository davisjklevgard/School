package edu.cvtc.java;

public class ShiftSupervisor extends Employee{

    //Attributes
    private double salary;
    private double bonus;

    //Default
    public ShiftSupervisor(){
        super();
    }

    //Overload
    public ShiftSupervisor(String name, String number, String hireDate, double salary, double bonus){
        super(name, number, hireDate);
        setSalary(salary);
        setBonus(bonus);
    }



    //Methods

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    public double getBonus() {
        return bonus;
    }

    public void setBonus(double bonus) {
        this.bonus = bonus;
    }

    public String toString() {
        String retVal = "";

        retVal += super.toString();
        retVal +=   "Salary: " + getSalary() + "\n";
        retVal += "Bonus: " + getBonus() + "\n";


        return retVal;
    }
}
