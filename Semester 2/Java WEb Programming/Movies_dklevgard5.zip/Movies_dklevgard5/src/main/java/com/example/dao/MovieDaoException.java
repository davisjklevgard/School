package com.example.dao;

public class MovieDaoException extends Exception{
    public MovieDaoException(String message) {
        super(message);
    }
}
