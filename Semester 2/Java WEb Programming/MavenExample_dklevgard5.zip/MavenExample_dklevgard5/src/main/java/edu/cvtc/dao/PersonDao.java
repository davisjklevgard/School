package edu.cvtc.dao;

import edu.cvtc.model.Person;

import java.util.List;

public interface PersonDao {

    public void populate(String filePath) throws PersonDaoException;

    public List<Person> retrievePeople() throws PersonDaoException;

    public void insertPerson(Person person) throws PersonDaoException;
}
