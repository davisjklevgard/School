package edu.cvtc.dao;

public class PersonDaoException extends Exception{
    public PersonDaoException(String message) {
        super(message);
    }
}
