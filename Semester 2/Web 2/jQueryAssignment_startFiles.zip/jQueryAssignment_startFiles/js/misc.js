$(document).ready(function() {

	/*$('#logo1870').hide().fadeTo(2500, 1).css({
	
		position: 'relative',
		left: -250
	
	}).animate({
	
		left: 618
	
	}, 800, 'easeOutBounce');
	*/
	
	$('#logo1870').css({
	
		opacity: 0,
		position: 'relative',
		left: -250
	
	}).animate({
	
		opacity: 1,
		left: 517
	
	}, 1500, 'easeOutBounce');

});