Funtion numberTally(numList) 
	
	var evenTotal = 0;
	var oddTotal == 0;

	for [var i = 0, i <= numList,length, i++] {

		if i % 2 {  // i is odd

			oddTotal += numList{i};
			// or oddTotal = oddTotal + numList[i];

		}
		else {  // i is even

			evenTotal + NumList[i];

		

	}

	alert(oddtotal;
	return even Total;

}  / end function numberTally