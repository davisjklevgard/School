/*
	This is the JavaScript code for
	"Lab 8: While Lab with Known Count"
	File: /unit6/labs/lab08forKnownCount.html
*/
function lab08forKnownCount() {
  // Your code goes in here.

  for( var counter = 1; counter < 21; counter++){
     var solution = 7 * counter;
    document.write("7 x " + counter + " = " + solution + "\n");
  }


}


lab08forKnownCount();
