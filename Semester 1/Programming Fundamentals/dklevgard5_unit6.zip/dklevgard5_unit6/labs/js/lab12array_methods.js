/*
	This is the JavaScript code for
	"Lab 12: Array Methods"
	File: /unit6/labs/lab12array_methods.html
*/

// your function declaration for isPalindrome()  goes here
// Rememer - it must take in the word and determine
// if it's a palendrome. It can't ask for input
// and it can't display any output. It must
// only return true or false. True if it's a palendrome
// and false if it's not.


// Then your main program starts here.
function lab12array_methods(){

  // prompt for input

  // logic  -- this is where you call your isPalindrome() function.

  // display output

  // You can delete the following line.
  document.write("The JavaScript file that produces this output is: " +
                  "\"/unit6/labs/js/lab12array_methods.js\"");
}

lab12array_methods();
