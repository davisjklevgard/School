function lab01movingJavaScript() {
  var firstName;
  var lastName;

  firstName = "Homer";
  lastName = "Simpson";

  document.write("Hello, " + firstName + " " + lastName);
}

lab01movingJavaScript();