/*
	This is the JavaScript code for
	"Lab 13: Hashes"
	File: /unit6/labs/lab13hashes.html
*/


function lab13hashes() {
  // Your code goes in here. Remember, each {} needs
  // a comma between each one, but we DON'T have
  // a comma after the last hash!
  var people = [

    {
      "firstName": "Homer",
      "lastName": "Simpson",
      "age": 42
    },
    {
      "firstName": "Marge",
      "lastName": "Simpson",
      "age": 42
    },
    {
      "firstName": "Bart",
      "lastName": "Simpson",
      "age": 10
    }
  ];


  document.write("The JavaScript file for this page is: " +
    "\"/unit6/jsFiles/lab13hashes.js\"");
}

lab13hashes();
