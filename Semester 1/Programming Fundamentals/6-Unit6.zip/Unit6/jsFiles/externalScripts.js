/*
  This is the JavaScript code for
  "A Quick Introduction to Functions"
  File: /unit6/externalScripts.html
*/
function externalScripts() {
  // Your code goes in here.
  document.write("The JavaScript file for this page is: " +
    "\"/unit6/jsFiles/externalScripts.js\"");
}

externalScripts();
