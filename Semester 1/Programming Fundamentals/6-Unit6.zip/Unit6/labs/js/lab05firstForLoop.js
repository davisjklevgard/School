/*
  This is the JavaScript code for
  "Lab 5: Your First For Loop"
  File: /unit6/labs/lab05firstForLoop.html
*/
function lab05firstForLoop() {
  // Your code goes in here.

  document.write("The JavaScript file that produces this output is: " +
                 "\"/unit6/labs/js/lab05firstForLoop.js\"");
}

lab05firstForLoop();
