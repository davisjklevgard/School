/*
  This is the JavaScript code for
  "Lab 11: Arrays"
  File: /unit6/labs/lab10firstLoopStopIf.html
*/
function lab11Arrays() {
  // Your code goes in here.

  document.write("The JavaScript file for this page is: " +
                 "\"/unit6/jsFiles/lab11arrays.js\"");
}


lab11Arrays();
