/*
  This is the JavaScript code for
  "Lab 4: Your First While Loop"
  File: /unit6/labs/lab04firstWhileLoop.html
*/
function lab04firstWhileLoop() {
  // Your code goes in here.


  document.write("The JavaScript file generating this output is: " +
                 "\"/unit6/labs/js/lab04firstWhileLoop.js\"");
}


lab04firstWhileLoop();
