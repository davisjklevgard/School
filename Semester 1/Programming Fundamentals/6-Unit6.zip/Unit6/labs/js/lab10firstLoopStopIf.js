/*
  This is the JavaScript code for
  "Lab 10: Stopping Loops IF"
  File: /unit6/labs/lab10firstLoopStopIf.html
*/
function lab10firstLoopStopIf() {
  // Your code goes in here.

  document.write("The JavaScript file for this page is: " +
                 "\"/unit6/jsFiles/lab10firstLoopStopIf.js\"");
}

lab10firstLoopStopIf();
