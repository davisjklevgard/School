/*
	This is the JavaScript code for
	"Lab 8: While Lab with Known Count"
	File: /unit6/labs/lab08forKnownCount.html
*/
function lab08forKnownCount() {
  // Your code goes in here.

  document.write("The JavaScript file that produced this output is: " +
    "\"/unit6/jsFiles/lab08forKnownCount.js\"");


}


lab08forKnownCount();
