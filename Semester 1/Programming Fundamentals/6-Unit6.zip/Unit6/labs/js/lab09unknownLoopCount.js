/*
  This is the JavaScript code for
  "Lab 9: Unknown Loop Count"
  File: /unit6/labs/lab09unknownLoopCount.html
*/
function lab09unknownLoopCount() {
  // Your code goes in here.

  document.write("The JavaScript file for this page is: " +
    "\"/unit6/jsFiles/lab09unknownLoopCount.js\"");
}

lab09unknownLoopCount();
