function rollDice(dice) {
  return dice = Math.floor((Math.random() * 12) + 2); 
}