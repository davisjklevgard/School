module.exports = function(grunt){
  grunt.initConfig({
    pkg: grunt.file.readJSON('package.json')
  });

  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.config("watch", {
    styles: {
      files: ['stylesheets/**/*.css']
    },
    interface: {
      files: ['**/*.html']
    },
    options: {
      livereload: true
    },
  
  });
  grunt.registerTask('default', ['watch']);
}

